<div class="row">
    <div class="col-md-12">
      <div class="card">
          <div class="header">
              <h4 class="title">Reporte Diario</h4>
              <p class="category">Seleccione la fecha
                <select class="form-control">
                  <option>10/05/16</option>
                </select>
              </p>
          </div>
          <div class="content">
              <div class="typo-line">
                  <p class="category">Detalle</p>
                  <blockquote>
                   <p>Disponible: <i>2:10 h</i></p>
                   <p>En llamada: <i>2:42 h</i></p>
                   <p>Reunion: <i>2:00 h</i></p>
                   <small>
                   Total de horas: 6:52 h
                   </small>
                  </blockquote>
              </div>
          </div>
        </div>
      </div>
    </div>
