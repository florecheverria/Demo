<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2 class="title">Estados de Agentes</h2>
                <!-- <p class="category">Tu estado es <a>Disponible</a>: <b>3:05 h</b></p> -->
            </div>
            <div class="content all-icons">
                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-check"></i>
                      <input type="text" value="Disponible">
                      30%
                    </div>

                  </div>
                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-headphones"></i>
                      <input type="text" value="Llamada">
                      10%
                    </div>
                  </div>

                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-delete-user"></i>
                      <input type="text" value="No disponible">
                      35%
                    </div>

                  </div>

                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-display2"></i>
                      <input type="text" value="Reunion">
                      20%
                    </div>

                  </div>

                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-coffee"></i>
                      <input type="text" value="Almuerzo">
                      5%
                    </div>

                  </div>

                </div>

            </div>
        </div>
    </div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Agentes</h4>
                <!-- <p class="category">Here is a subtitle for this table</p> -->
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>Estado</th>
                      <th>Nombre</th>
                      <th>Apellido</th>
                    </thead>
                    <tbody>
                        <tr>
                          <td></td>
                          <td>Jose</td>
                          <td>Perez</td>
                        </tr>
                        <tr>
                          <td></td>
                          <td>Maria</td>
                          <td>Ramirez</td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

</div>
