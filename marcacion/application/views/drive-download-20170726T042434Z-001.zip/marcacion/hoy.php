<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h2 class="title">Hoy</h2>
                <p class="category">Tu estado es <a>Disponible</a>: <b>3:05 h</b></p>
            </div>
            <div class="content all-icons">
                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-check"></i>
                      <input type="text" value="Disponible">
                    </div>

                  </div>
                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-headphones"></i>
                      <input type="text" value="Llamada">
                    </div>
                  </div>

                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-delete-user"></i>
                      <input type="text" value="No disponible">
                    </div>

                  </div>

                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-display2"></i>
                      <input type="text" value="Reunion">
                    </div>

                  </div>

                  <div class="font-icon-list col-lg-2 col-md-2 col-sm-4 col-xs-6 col-xs-6">
                    <div class="font-icon-detail"><i class="pe-7s-coffee"></i>
                      <input type="text" value="Almuerzo">
                    </div>

                  </div>

                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Actividades</h4>
                    <!-- <p class="category">Created using Roboto Font Family</p> -->
                </div>
                <div class="content">
                    <div class="typo-line">
                        <p class="category">Detalle</p>
                        <blockquote>
                         <p>Disponible: <i>2:10 h</i></p>
                         <p>En llamada: <i>2:42 h</i></p>
                         <p>Reunion: <i>2:00 h</i></p>
                         <small>
                         Total de horas: 6:52 h
                         </small>
                        </blockquote>
                    </div>
                </div>
            </div>
        </div>

    </div>
